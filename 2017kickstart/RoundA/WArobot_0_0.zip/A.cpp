#include "iostream"
#include "algorithm"
#include "cstdlib"
#include "cstdio"
using namespace std;

const int M = 1e9+7;
long long sum;

int main(){
  int t,r,c,kase;
  // freopen("A-small-attempt6.in","r",stdin);
  // freopen("outtext.txt","w",stdout);

  cin>>t;
  kase=0;
  while(t--){
    sum = 0;
    cin>>r>>c;
    long long n=min(r,c);
    for(int i=1;i<n;i++){
      sum += (r-i)*(c-i);
    }
    for(int i=2;i<n;i++){
      sum+=(r-i)*(c-i)*(i-1);
    }
    sum %= M;
    kase++;
    printf("Case #%d: ",kase);
    cout<<sum<<endl;
  }
  return 0;
}
