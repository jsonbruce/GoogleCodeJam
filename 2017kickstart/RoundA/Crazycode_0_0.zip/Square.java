import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
public class Square {
	public static int num(int x, int y)
	{
		int sum=0;
		int s=min(x,y);
		for (int i=2;i<=s;i++)
		{
			sum=sum%1000000007+(x-i+1)*(y-i+1)*(i-1)%1000000007;
		}
		return sum;
	}
	public static int min(int x, int y)
	{
		if(x>=y) return y;
		else return x;
	}
	 public static void main(String[] args) throws IOException  
	 {
		 int T=1;
		 int x=831;
		 int y=366;
		 ArrayList<String> list = new ArrayList<String>();
		 BufferedReader br = new BufferedReader(new FileReader("D:\\A-small-attempt3.in"));
			String reads =null;
			while((reads=br.readLine())!=null)                  
			{
				StringTokenizer st= new StringTokenizer(reads,"\t\r\f\n ");
				while(st.hasMoreTokens())
				{
					list.add(st.nextToken());
				}
			}  
			T=Integer.parseInt(list.get(0));
		 String timepath="D:\\result.txt";
		 FileOutputStream dos =new FileOutputStream(timepath);
		 for(int i=1;i<=T;i++)
		   {   
			 x=Integer.parseInt(list.get(i*2-1));
			 y=Integer.parseInt(list.get(i*2));
			 String str="Case #"+i+": "+num(x,y)+"\n";
			 byte bytes[]=new byte[str.length()*2];
			 bytes=str.getBytes();
			 int b=str.length();
			 dos.write(bytes,0,b);
			 System.out.println("Case #"+i+": "+num(x,y));
		   } 
	 }
}
