#include<stdio.h>
#include<stdlib.h>
long squares(int r , int c);
void main()
{
	int n;
	scanf("%d", &n);
	int i=0;
	int r; int c;
	while(i<n)
	{
		scanf("%d %d",&r , &c);
		printf("Case #%d: %ld\n",i+1 , squares(r,c)); i++;
	}
}
long squares(int r , int c)
{
	r--;
	c--;
	long res=0;
	if(r==c)
	{	
		int i=1;
		while(i<=r)
		{
			res+=i*i*(r-i+1); i++;
		}
		return res%1000000007;
	}
	if(r<c)
	{
		int i=1;
		while(i<=r)
		{
			res+=i*i*(r-i+1); i++;
		}
		for(i=1 ; i<=c-r ; i++)
		{ 
			int j=1;
			while(j<=r)
			{
				res+=j*(r-j+1); j++;
			}
		}	
		return res%1000000007;	
	
	}
		if(c<r)
	{
		int i=1;
		while(i<=c)
		{
			res+=i*i*(c-i+1); i++;
		}
		for(i=1 ; i<=r-c ; i++)
		{ 
			int j=1;
			while(j<=c)
			{
				res+=(j)*(c-j+1);  j++;
			}
		}	
		return res%1000000007;	
	
	}
}
