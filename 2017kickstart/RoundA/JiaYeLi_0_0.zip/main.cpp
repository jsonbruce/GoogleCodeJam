#include <iostream>

using namespace std;
const long long int M=1000000007;

long long int add(long long int a, long long int b)
{
    return (a+b)%M;
}

long long int ans(int R, int C)
{
    if(R<=1||C<=1)
        return 0;

    long long int m = min(R,C);
    long long int sum = 0;
    for(long long int i=1; i<=m;i++)
    {
        sum = add(sum, (R-i)*(C-i));
        if(i+i<=m-1)
            sum = add(sum, (R-(i+i))*(C-(i+i)));
        for(long long int j=i+1;j+i<=m-1;j++)
        {
            sum = add(sum, 2*(R-(i+j))*(C-(i+j)));
        }
    }
    return sum;
}

int main()
{
    int T=0;

    cin >> T;

    for(int t=0; t<T; t++)
    {
        long long int R = 0,C = 0;
        cin >> R >> C;



        cout << "Case #"<<t+1<<": "<<ans(R,C) << endl;
    }

    return 0;
}
