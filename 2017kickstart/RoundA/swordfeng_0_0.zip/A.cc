#include <cstdio>
#include <iostream>
#include <utility>

using namespace std;

const long long mod = 1000000000LL+7;
const long long rev12 = 83333334; // https://www.wolframalpha.com/input/?i=12+%5E++(-1)+mod+(10%5E9%2B7)

int main() {
    int t;
    scanf("%d", &t);
    for (int ii = 1; ii <= t; ii++) {
        long long r, c;
        cin >> r >> c;
        if (r > c) swap(r, c);
        printf("Case #%d: ", ii);
        cout << ((r * ((r*r-1) % mod) % mod) * (2*c - r) % mod) * rev12 % mod << endl;
    }
    return 0;
}
