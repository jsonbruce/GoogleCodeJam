package RoundA;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import Utils.FileUtil;

public class SquareCounting {
	public static void main(String[] args){
        
        InputStreamReader is = FileUtil.getReader("src/RoundA/small1.in");
        BufferedReader bf = new BufferedReader(is);
        try {
            int T = Integer.parseInt(bf.readLine());
            StringBuffer sb = new StringBuffer("");
            for(int i = 1 ; i <= T; i ++){
            	String[] numbers = bf.readLine().split(" ");
                long m  = Long.parseLong(numbers[0]);
                long n = Long.parseLong(numbers[1]);
                if(m > n){
                	long temp = m;
                	m = n;
                	n = temp;
                }
                long result = helper(m, n);
                sb.append("Case #" + i + ": " + result + "\n");
            }
            FileUtil.write("src/RoundA/result.out",sb.toString());

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
	public static long helper(long m, long n){
		long MOD = 1000000007;
	    long res=0;
	    res = ((m-1)*(m-1)*m*m/4 + m*n*(m-1)*m/2 - (m+n)*(m-1)*m*(2*m-1)/6)%MOD;
	    res %= MOD;
	    return res;

	}
	
}
