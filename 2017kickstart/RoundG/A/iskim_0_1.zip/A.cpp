#pragma GCC target("popcnt")
#include <cctype>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <algorithm>
#include <bitset>
#include <complex>
#include <deque>
#include <functional>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <vector>
#include <array>
#include <initializer_list>
#include <random>
#include <regex>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/detail/standard_policies.hpp>
using namespace __gnu_pbds;
using namespace std;

int visit[100005];

int main()
{
    int T;
    scanf("%d",&T);
    for (int tt = 1; tt <= T; tt++)
    {
        memset(visit, 0, sizeof(visit));
        printf("Case #%d: ", tt);
        int a, n, p;
        scanf("%d%d%d",&a,&n,&p);

        int x = 1;
        for (int i = 1; i <= min(n, 10); i++) x = x * i;

        int i, now = 1;
        for (i = 1; visit[now] == 0; i++)
        {
            visit[now] = i;
            now = now * 1ll * a % p;
            if (--x == 0)
            {
                printf("%d\n", now);
                break;
            }
        }

        if (x == 0) continue;

        int loop = i - visit[now];
        int rem = 1;
        for (int x = 1; x <= n; x++) rem = rem * 1ll * x % loop;
        rem = rem - visit[now] + 1;
        while (rem < 0) rem += loop;

        while (rem--)
        {
            now = now * 1ll * a % p;
        }

        printf("%d\n", now);
    }
}
