#include <bits/stdc++.h>
#define MOD 1000000007
using namespace std;

int TC, N, A[10005];

int main() {
	scanf("%d", &TC);
	for (int tc = 1; tc <= TC; tc++) {
		scanf("%d", &N);
		for (int i = 0; i < N; i++) scanf("%d", &A[i]);
		sort(A, A + N);
		int cur = 1;
		long long ans = 0;
		for (int i = 0; i < N; i++) {
			ans += (long long)A[i] * cur;
			ans %= MOD;
			cur *= 2;
			cur %= MOD;
		}
		cur = 1;
		for (int i = N - 1; i >= 0; i--) {
			ans -= (long long)A[i] * cur;
			ans %= MOD;
			ans += MOD;
			ans %= MOD;
			cur *= 2;
			cur %= MOD;
		}
		printf("Case #%d: %lld\n", tc, ans);
	}
		
}
