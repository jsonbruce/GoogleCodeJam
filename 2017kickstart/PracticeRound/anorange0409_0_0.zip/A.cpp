#include <iostream>
#include <set>
#include <map>
#include <queue>
#include <sstream>
#include <algorithm>
#include <cstdio>
using namespace std;

int count(string s) {
    set<char> S;
    for (int i = 0; i < s.size(); i++)
        if (s[i] != ' ')
            S.insert(s[i]);
    return S.size();
}

int main() {
    freopen("A-small-attempt0.in", "r", stdin);
    freopen("As.out", "w", stdout);
    int T,n;
    cin >> T;
    for (int o = 1; o <= T; o++) {
        cin >> n;
        string s; int best = 0;
        string win;
        getchar();
        for (int i = 0; i < n; i++) {
            getline(cin, s);
            int k = count(s);
            //cout << s << " " << k << endl;
            if (k>best||k==best&&s<win) {
                best = k;
                win = s;
            }
        }
        printf("Case #%d: %s\n",o,win.c_str());
    }
    return 0;
}



