
#include <iostream>
#include <algorithm>
#include <string.h>
#include <math.h>
#include <set>

using namespace std;

#define pb push_back
#define mp make_pair
#define ll long long
#define ull unsigned ll
#define db double
#define INF 0x3f3f3f3f
#define MOD 1000000007
#define PII pair<int, int>

const string INPUT_FILE = "input.txt";
const string OUTPUT_FILE = "a.txt";

int t;
int n;

int cnt(string& str) {
    set<char> s;
    for (char c:str) {
        if (c!=' ') s.insert(c);
    }
    return s.size();
}

int main() {

    freopen(INPUT_FILE.c_str(), "r", stdin);
    freopen(OUTPUT_FILE.c_str(), "w", stdout);

    scanf("%d\n",&t);
    for (int tt=1;tt<=t;tt++) {
        printf("Case #%d: ",tt);
        scanf("%d\n",&n);
        string str;
        string ans;
        for (int i=0;i<n;i++) {
            getline(cin,str);
            int x=cnt(str);
            int y=cnt(ans);
            if (i>0) {
                if (x>y) {
                    ans=str;
                } else if (x==y) {
                    if (str<ans) ans=str;
                }
            } else {
                ans=str;
            }
        }
        printf("%s\n",ans.c_str());
    }
}